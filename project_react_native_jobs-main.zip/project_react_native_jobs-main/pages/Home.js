import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const HomeScreen = () => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.logo}>Logo</Text>
        <Text style={styles.menu}>Menu</Text>
      </View>
      <View style={styles.mainContent}>
        <Text style={styles.title}>Welcome to My App</Text>
        <Text style={styles.subtitle}>Browse Our Latest Posts</Text>
        <View style={styles.itemContainer}>
          <Text style={styles.item}>Post 1</Text>
          <Text style={styles.item}>Post 2</Text>
          <Text style={styles.item}>Post 3</Text>
        </View>
        <TouchableOpacity style={styles.ctaButton}>
          <Text style={styles.ctaText}>Learn More</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  logo: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  menu: {
    fontSize: 20,
  },
  mainContent: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 40,
    alignItems: 'center',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  subtitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  itemContainer: {
    marginBottom: 20,
  },
  item: {
    fontSize: 20,
    marginBottom: 10,
  },
  ctaButton: {
    backgroundColor: 'blue',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  ctaText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
});

export default HomeScreen;
